<?php
// ID продавца в сервисе Digiseller.ru
$id_seller = 1;

// пароль продавца
$pass_DS = ""; 
?>